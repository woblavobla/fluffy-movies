# -*- coding: utf-8 -*-
# require 'index/controller_issues_new_before_save_hook'

require 'index'


Redmine::Plugin.register 'milofon_index' do
  name 'index - технология библиографии'
  author 'Коптев Алексей'
  description 'Ведение библиографических баз данных. Формирование библиографических записей, ссылок и указателей. Формирование ссылок на нормативные документы и их фаргменты.'
  version '1.0.1'
  url 'https://basis.milofon.org'


  Redmine::WikiFormatting::Macros.register do
    desc 'Формирование библиографической ссылки'
    macro :cite do |obj, args|

      raise I18n.t(:index_wrong_count_of_arguments) if (args.size != 1)
      ActiveSupport::SafeBuffer.new(Index::issue_to_bib(args[0].strip, :citation))

    end
  end

  Redmine::WikiFormatting::Macros.register do
    desc 'Формирование библиографической записи'
    macro :bib do |obj, args|

      raise I18n.t(:index_wrong_count_of_arguments) if (args.size != 1)
      ActiveSupport::SafeBuffer.new(Index::issue_to_bib(args[0].strip, :bibliography))

    end
  end

  Redmine::WikiFormatting::Macros.register do
    desc 'Формирование библиографического указателя'
    macro :index do |obj, args, text|

      raise I18n.t(:index_index_wrong_count_of_arguments) if (args.size != 1)

      style = args[0].strip
      out = ''
      index = 0

      if style == 'cite' then
        text.lines.each do |line|
          if line.strip != ''
            index = index + 1
            out = out + index.to_s + '. ' + Index::issue_to_bib(line.strip, :citation) + '<br></br>'
          end
        end
      else
        text.lines.each do |line|
          if line.strip != ''
            index = index + 1
            out = out + index.to_s + '. ' + Index::issue_to_bib(line.strip, :bibliography) + '<br></br>'
          end
        end
      end
      ActiveSupport::SafeBuffer.new(out)
    end
  end

  Redmine::WikiFormatting::Macros.register do
    desc 'Формирование ссылки на нормативный документ'
    macro :norma do |obj, args|

      raise I18n.t(:index_wrong_count_of_arguments) if (args.size == 0)
      return ActiveSupport::SafeBuffer.new(Index::issue_to_bib(args[0].strip, :norma)) if args.size == 1
      return ActiveSupport::SafeBuffer.new(Index::issue_to_bib(args[0].strip, :norma) + " (#{args[1].strip})") if args.size == 2

    end
  end

  Redmine::WikiFormatting::Macros.register do
    desc 'Формирование ссылки на фрагмент нормативного документа'
    macro :extract do |obj, args|

      raise I18n.t(:index_wrong_count_of_arguments) if (args.size != 2)
      ActiveSupport::SafeBuffer.new('[' + Index::issue_to_bib(args[0].strip, :extract) + ", #{args[1].strip}]")

    end
  end

  Redmine::WikiFormatting::Macros.register do
    desc 'Формирование ссылки на библиографическую запись'
    macro :bibkey do |obj, args|

      raise I18n.t(:index_wrong_count_of_arguments) if (args.size != 1)

      issue = Issue.find_by_subject(args[0].strip)

      raise I18n.t(:index_entry_is_not_found, :value => args[0].strip) unless issue

      link = "<a href=\"#{Setting.protocol}://#{Setting.host_name}/issues/#{issue.id.to_s}\" class=\"wiki-page\">#{args[0].strip}</a>"

      return ActiveSupport::SafeBuffer.new(link) if args.size == 1

    end
  end

end

ActiveSupport::Reloader.to_prepare do
  require_dependency 'issue'
  Issue.send(:include, IndexRequireIssueUniqueBib::Patches::IssuePatch)
end

