# -*- coding: utf-8 -*-
require 'rubygems'
require 'bibtex'
require 'citeproc'
require 'csl/styles'


module Index

  STYLE = CSL::Style.load(Rails.root.join('plugins','milofon_index','lib','index-bib.csl'))
  CP = CiteProc::Processor.new style: STYLE, format: 'text'
  BIB = BibTeX::Bibliography.new

  # Формирование библиографической записи или ссылки
  # Если существует wiki страница с таким же как и у записи ключем, то добавляется ссылка на эту wiki страницу
  # Если wiki страница отсутствует, но поле URL заполнено, то добавляется ссылка на указанный URL
  def self.issue_to_bib (bibtex_key, type)

    issue = Issue.find_by_subject(bibtex_key)

    raise I18n.t(:index_entry_is_not_found, :value => bibtex_key) unless issue


    heading = ''
    author = ''
    title = ''
    subtitle = ''
    media = ''
    specdata = ''
    address = ''
    publisher = ''
    year = ''
    pagetotal = ''
    series = ''
    url = ''
    language = ''
    mclass = ''
    mrule = ''
    mtype = ''

    issue.custom_field_values.each do |cf|
      heading = cf.value if cf.custom_field.name == '01-01.Заголовок'
      author = cf.value if cf.custom_field.name == '01-02.Автор'
      title = cf.value if cf.custom_field.name == '01-03.Заглавие'
      subtitle = cf.value if cf.custom_field.name == '01-04.Подзаглавие'
      media = cf.value.split(' - ')[0] if cf.custom_field.name == '01-05.Материал'
      specdata = cf.value if cf.custom_field.name == '01-06.Сведения'
      address = cf.value if cf.custom_field.name == '01-07.Адрес'
      publisher = cf.value if cf.custom_field.name == '01-08.Издательство'
      year = cf.value if cf.custom_field.name == '01-09.Год'
      pagetotal = cf.value if cf.custom_field.name == '01-10.Страницы'
      series = cf.value if cf.custom_field.name == '01-11.Серия'
      url = cf.value if cf.custom_field.name == '01-12.URL'
      language = cf.value.split(' - ')[0] if cf.custom_field.name == '01-13.Язык'
      mclass = cf.value.split(' - ')[0] if cf.custom_field.name == '01-14.Класс'
      mrule = cf.value.split(' - ')[0] if cf.custom_field.name == '01-15.Правило'
      mtype = cf.value.split(' - ')[0] if cf.custom_field.name == '01-16.Тип'
    end

    description = issue.description


    e = BibTeX::Entry.new
    e.key = issue.subject
    e.add(:heading, heading) 
    e.add(:author, author)
    e.add(:title, title)
    e.add(:subtitle, subtitle)
    e.add(:media, media)
    e.add(:specdata, specdata)
    e.add(:address, address)
    e.add(:publisher, publisher)
    e.add(:year, year)
    e.add(:pagetotal, pagetotal)
    e.add(:series, series)
    e.add(:url, url)
    e.add(:language, language)
    e.add(:hyphenation, 'russian')
    e.add(:mclass, mclass)
    e.add(:mrule, mrule)
    e.add(:mtype, mtype)
    e.add(:annotation, description)
    e.type = "#{mrule}_#{mtype}"

    BIB.add e

    CP.import BIB.to_citeproc

    name = CP.render( :citation, id: issue.subject) if type == :citation
    name = CP.render( :bibliography, id: issue.subject)[0] if type == :bibliography
    name = heading.strip[0,heading.index(/-([0-9]{4}|[0-9]{2})$/)] if type == :norma
    name = heading.strip if type == :extract

    BIB.delete e

    wp = WikiPage.find_by_title(issue.subject)
    if wp then
      "<a href=\"#{Setting.protocol}://#{Setting.host_name}/projects/#{wp.project.identifier}/wiki/#{wp.title}\" class=\"wiki-page\">#{name}</a>"
    elsif url != ''
      "<a href=\"#{url}\" class=\"external\">#{name}</a>"
    else
      name
    end
  end

  # Возвращает значение справочника по коду из bibtex
  def self.translate_code (code, field)
    
    field = IssueCustomField.find_by_id field.id
    field.possible_values.each do |v|
      return v if v.include? "#{code} - "
    end
  end

  # Устанавливает значение дополнительного реквизита
  def self.set_field_value (issue, field_name, value)
    
    field = IssueCustomField.find_by_name(field_name)
    issue.custom_field_values = { field.id => value }

  end

  # Устанавливает значение дополнительного реквизита
  def self.set_field_code (issue, field_name, code)
    
    field = IssueCustomField.find_by_name(field_name)
    issue.custom_field_values = { field.id => Index::translate_code(code, field) }

  end

end
