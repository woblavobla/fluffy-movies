# -*- coding: utf-8 -*-

module IndexRequireIssueUniqueBib
  module Patches
    module IssuePatch
      def self.included(base)
        base.class_eval do
          unloadable

          validate :unique_bib

          protected
          def unique_bib
            other = Issue.find_by_subject(subject)
            return true if not ( tracker.name == "ССЫЛКА" and (other ? (other.id != id ? true : false) : false)) 

            errors.add :subject, :unique_bib
            
          end
          
        end
      end
    end
  end
end
