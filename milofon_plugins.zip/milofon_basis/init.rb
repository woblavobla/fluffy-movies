# -*- coding: utf-8 -*-

# Copyright (c) 2015-2016, Alexey Koptev, Oleg Lelenkov. All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
# COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.

# подключаем точку расширения для включения стилей модуля
require 'hooks/basis_view_layouts_base_html_head_hook'

# подключаем точку расширения для установки автора примечаний
require 'hooks/basis_controller_author_issue_hook'

# -------------------------------------------------------
# подключаем библиотеку оформления листингов bash

require 'coderay'

path = File.join File.expand_path(File.dirname(__FILE__))

require File.join(path, "lib/coderay/bash.rb")
require File.join(path, "lib/coderay/erb_bash.rb")

# Register file types
::CodeRay::FileType::TypeFromExt['sh'] = :bash
# -------------------------------------------------------

require_dependency 'patches/basis_author_issue_patch'

Rails.configuration.to_prepare do
  unless Issue.included_modules.include?(ChangeAuthorIssuePatch)
    Issue.send(:include, ChangeAuthorIssuePatch)
  end
end


Redmine::Plugin.register 'milofon_basis' do
  name 'basis - технология развития'
  author 'Коптев Алексей'
  description 'Общие расширения к программному средству Redmine. Оформление листингов bash. Адаптация эргономики. Запуск локальных ппрограмм и вывод в wiki'
  version '1.4.0'
  url 'https://basis.milofon.org'
  author_url 'https://basis.milofon.org'
end

Redmine::WikiFormatting::Macros.register do
  desc 'Выполнение программы и вывод результатов в wiki'
  macro :bashme do |obj, args|

    raise I18n.t(:index_wrong_count_of_arguments) if (args.size != 1)
    # return "#{File.join(Rails.root, 'bin', args[0].strip)}"
    return ActiveSupport::SafeBuffer.new(textilizable `#{File.join(Rails.root, 'bin', args[0].strip)}`)
    
  end
end
