class UpdatesNotifierIssueChangeListener < Redmine::Hook::Listener
  def controller_issues_edit_before_save(context={})
    unless context[:params][:issue][:author_id].blank?
      author_id = context[:params][:issue][:author_id]
      context[:journal].user_id = author_id
    end
  end
end
