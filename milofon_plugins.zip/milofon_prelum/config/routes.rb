# Plugin's routes
# See: http://guides.rubyonrails.org/routing.html

post 'check/:field_id/:obj_id', :to => 'check#check'

get 'templates', :to => 'templates#index'

get 'templates/:id', :to => 'templates#text'

get 'memo/:key', :to => 'memo#memo'

get 'dictionaries/:locale/:file', :to => 'spell#getdic', file: /[a-z][a-z]_[A-Z][A-Z]\.(?:aff|dic)/

