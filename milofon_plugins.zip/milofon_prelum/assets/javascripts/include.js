// Copyright (c) 2015, Alexey Koptev, Oleg Lelenkov. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice,
//    this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
// 3. Neither the name of the copyright holder nor the names of its contributors
//    may be used to endorse or promote products derived from this software
//    without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
// COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
// INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL DAMAGES (INCLUDING,
// BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
// AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
// OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
// OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.



// использованы идеи http://lifeexample.ru/jquery-javascript-primeryi/js-include-i-js-require.html

var list = [];

function require_js (url) {

    for (var i = 0; i < list.length; i++) {
	if (list[i] == url) {
	    return false;
	}
    }

    list.push(url);
    
    $.ajax({
	url: url,
	dataType: "script",
	async: false
    });

};

// ---------------------------

/**
 * A simple implementation to format strings: E.g. `'{0}'.format ('alpha')`.
 */

if (!String.prototype.format) {
    String.prototype.format = function () {
	var args = arguments;
	return this.replace (/{(\d+)}/g, function (match, number) {
	    return typeof args[number] != 'undefined' ? args[number] : match;
	});
    };
}

if (!String.format) {
    String.format = function () {

	var args = Array.prototype.slice.call (arguments);
	var self = args.shift ();

	return self.replace (/{(\d+)}/g, function (match, number) {
	    return typeof args[number] != 'undefined' ? args[number] : match;
	});
    };
}


// ----------------------------

Array.prototype.unique = function() {
    var a = this.concat();
    for(var i=0; i<a.length; ++i) {
	for(var j=i+1; j<a.length; ++j) {
	    if(a[i] === a[j])
		a.splice(j--, 1);
	}
    }

    return a;
};

// var array3 = array1.concat(array2).unique(); 

// -----------------------------------

function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}

// -----------------------------------

String.prototype.scan = function (re) {

    if (!re.global) throw "regex must have 'global' flag set";
    var s = this;
    var m, r = [];
    while (m = re.exec(s)) {
	m.shift();
	r.push(m[0]);
    }
    return r;
};
