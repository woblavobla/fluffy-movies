/* ***** BEGIN LICENSE BLOCK *****
 * This file is part of DotClear.
 * Copyright (c) 2005 Nicolas Martin & Olivier Meunier and contributors. All
 * rights reserved.
 *
 * DotClear is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * DotClear is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with DotClear; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * ***** END LICENSE BLOCK *****
 */

/* Modified by JP LANG for textile formatting */
/* Modified by Alexey Koptev for use into milofon-prelum plugin*/

// strong
jsToolBarCM.prototype.elements.strong = {
    type: 'button',
    title: 'Strong',
    fn: {
	wiki: function() { this.singleTag('*') }
    }
}

// em
jsToolBarCM.prototype.elements.em = {
    type: 'button',
    title: 'Italic',
    fn: {
	wiki: function() { this.singleTag("/") }
    }
}

// ins
jsToolBarCM.prototype.elements.ins = {
    type: 'button',
    title: 'Underline',
    fn: {
	wiki: function() { this.singleTag('_') }
    }
}

// del
jsToolBarCM.prototype.elements.del = {
    type: 'button',
    title: 'Deleted',
    fn: {
	wiki: function() { this.singleTag('-') }
    }
}

// code
jsToolBarCM.prototype.elements.code = {
    type: 'button',
    title: 'Code',
    fn: {
	wiki: function() { this.singleTag('@') }
    }
}

// spacer
jsToolBarCM.prototype.elements.space1 = {type: 'space'}

// headings
jsToolBarCM.prototype.elements.h1 = {
    type: 'button',
    title: 'Heading 1',
    fn: {
	wiki: function() {
	    this.encloseLineSelection('+ ', '',function(str) {
		str = str.replace(/^\+\s+/, '')
		return str;
	    });
	}
    }
}
jsToolBarCM.prototype.elements.h2 = {
    type: 'button',
    title: 'Heading 2',
    fn: {
	wiki: function() {
	    this.encloseLineSelection('++ ', '',function(str) {
		str = str.replace(/^\+\+\s+/, '')
		return str;
	    });
	}
    }
}
jsToolBarCM.prototype.elements.h3 = {
    type: 'button',
    title: 'Heading 3',
    fn: {
	wiki: function() {
	    this.encloseLineSelection('=+ ', '',function(str) {
		str = str.replace(/^=\+\s+/, '')
		return str;
	    });
	}
    }
}

// spacer
jsToolBarCM.prototype.elements.space2 = {type: 'space'}

// ul
jsToolBarCM.prototype.elements.ul = {
    type: 'button',
    title: 'Unordered list',
    fn: {
	wiki: function() {
	    this.encloseLineSelection('','',function(str) {
		str = str.replace(/\r/g,'');
		return str.replace(/(\n|^)[#-]?\s*/g,"$1- ");
	    });
	}
    }
}

// ol
jsToolBarCM.prototype.elements.ol = {
    type: 'button',
    title: 'Ordered list',
    fn: {
	wiki: function() {
	    this.encloseLineSelection('','',function(str) {
		str = str.replace(/\r/g,'');
		return str.replace(/(\n|^)[*-]?\s*/g,"$1) ");
	    });
	}
    }
}

// spacer
jsToolBarCM.prototype.elements.space3 = {type: 'space'}


// pre
jsToolBarCM.prototype.elements.pre = {
    type: 'button',
    title: 'Preformatted text',
    fn: {
	wiki: function() { this.encloseLineSelection('листинг(bash)\n', '\n--') }
    }
}

// image
jsToolBarCM.prototype.elements.img = {
    type: 'button',
    title: 'Image',
    fn: {
	wiki: function() { this.encloseSelection("рисунок(рис-1, png)", "") }
    }
}

// spacer
jsToolBarCM.prototype.elements.space5 = {type: 'space'}

// help
jsToolBarCM.prototype.elements.help = {
    type: 'button',
    title: 'Help',
    fn: {
	wiki: function() { window.open(this.help_link, '', 'resizable=yes, location=no, width=300, height=640, menubar=no, status=no, scrollbars=yes') }
    }
}

// spacer
jsToolBarCM.prototype.elements.space6 = {type: 'space'}


jsToolBarCM.prototype.elements.templates = {
    type: 'combo',
    id: 'prelumTemplates',
    title: 'Templates',
    options: $.ajax({
	url: document.location.protocol + "//" + document.location.host + "/templates/",
	async: false,
	dataType: "json"
    }).responseJSON,
    fn: {
	wiki: function(opt) {
	    var str = $.ajax({
    		url: document.location.protocol + "//" + document.location.host + "/templates/" + opt,
    		async: false,
    		dataType: "json"
	    }).responseText;
	    var retVal = confirm("[0002] Применение шаблона документа заместит имеющийся текст. Вы действительно хотите применить шаблон документа ?");
	    if( retVal == true ){
		window.prelumEditor.setValue(str);
		return true;
	    }
	}
    }
}

// spacer
jsToolBarCM.prototype.elements.space7 = {type: 'space'}

// check
jsToolBarCM.prototype.elements.check = {
    type: 'button',
    title: 'Check',
    fn: {
	wiki: function() { editor.setOption('lint', {lintOnChange: false}); }
    }
}
