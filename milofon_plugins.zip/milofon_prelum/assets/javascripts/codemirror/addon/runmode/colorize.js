// CodeMirror, copyright (c) by Marijn Haverbeke and others
// Distributed under an MIT license: http://codemirror.net/LICENSE

// Modified by Alexey Koptev for use with  milofon-prelum

// запускать в директории mode

// grep -r defineMIME ./ | gawk 'match($0, /\.\/\/([a-z0-9-]+)\/.*defineMIME\(.([a-z\/0-9-]+)/, a) {split(a[2],b,"/"); lang = b[2]; gsub(/x-/,"",lang); print  "\"" lang "\": {mode:\"" a[1] "\", mime: \"" a[2] "\"}," }' | sort -k 2

// заменить sh на bash

// вставить вывод в modemime
// далее отдельно для clike, modelica и ttcn выполнить
// cat clike/clike.js | grep 'text/x-.*'


(function(mod) {
  if (typeof exports == "object" && typeof module == "object") // CommonJS
    mod(require("../../lib/codemirror"), require("./runmode"));
  else if (typeof define == "function" && define.amd) // AMD
    define(["../../lib/codemirror", "./runmode"], mod);
  else // Plain browser env
    mod(CodeMirror);
})(function(CodeMirror) {
  "use strict";

 
	


    var modemime = {
		"apl": {mode:"apl", mime: "text/apl"},
		"pgp": {mode:"asciiarmor", mime: "application/pgp"},
		"pgp-keys": {mode:"asciiarmor", mime: "application/pgp-keys"},
		"pgp-signature": {mode:"asciiarmor", mime: "application/pgp-signature"},
		"ttcn-asn": {mode:"asn-1", mime: "text/x-ttcn-asn"},
		"ttcn": {mode:"ttcn", mime: "text/x-ttcn"},
		"ttcn3": {mode:"ttcn", mime: "text/x-ttcn3"},
		"ttcnpp": {mode:"ttcn", mime: "text/x-ttcnpp"},
		"asterisk": {mode:"asterisk", mime: "text/x-asterisk"},
		"brainfuck": {mode:"brainfuck", mime: "text/x-brainfuck"},
		"edn": {mode:"clojure", mime: "application/edn"},
		"c": {mode:"clike", mime: "text/x-c"},
  		"chdr": {mode:"clike", mime: "text/x-chdr"},
  		"c++": {mode:"clike", mime: "text/x-c++src"},
  		"c++hdr": {mode:"clike", mime: "text/x-c++hdr"},
  		"java": {mode:"clike", mime: "text/x-java"},
  		"c#": {mode:"clike", mime: "text/x-csharp"},
  		"scala": {mode:"clike", mime: "text/x-scala"},
  		"kotlin": {mode:"clike", mime: "text/x-kotlin"},
  		"nesc": {mode:"clike", mime: "text/x-nesc"},
  		"objective-c": {mode:"clike", mime: "text/x-objectivec"},
  		"squirrel": {mode:"clike", mime: "text/x-squirrel"},
  		"ceylon": {mode:"clike", mime: "text/x-ceylon"},
		"clojure": {mode:"clojure", mime: "text/x-clojure"},
		"clojurescript": {mode:"clojure", mime: "text/x-clojurescript"},
		"cmake": {mode:"cmake", mime: "text/x-cmake"},
		"cobol": {mode:"cobol", mime: "text/x-cobol"},
		"coffeescript": {mode:"coffeescript", mime: "text/coffeescript"},
		"coffeescript": {mode:"coffeescript", mime: "text/x-coffeescript"},
		"common-lisp": {mode:"commonlisp", mime: "text/x-common-lisp"},
		"crystal": {mode:"crystal", mime: "text/x-crystal"},
		"css": {mode:"css", mime: "text/css"},
		"gss": {mode:"css", mime: "text/x-gss"},
		"less": {mode:"css", mime: "text/x-less"},
		"scss": {mode:"css", mime: "text/x-scss"},
		"cypher-query": {mode:"cypher", mime: "application/x-cypher-query"},
		"d": {mode:"d", mime: "text/x-d"},
		"dart": {mode:"dart", mime: "application/dart"},
		"diff": {mode:"diff", mime: "text/x-diff"},
		"django": {mode:"django", mime: "text/x-django"},
		"dockerfile": {mode:"dockerfile", mime: "text/x-dockerfile"},
		"xml-dtd": {mode:"dtd", mime: "application/xml-dtd"},
		"dylan": {mode:"dylan", mime: "text/x-dylan"},
		"ebnf": {mode:"ebnf", mime: "text/x-ebnf"},
		"ecl": {mode:"ecl", mime: "text/x-ecl"},
		"eiffel": {mode:"eiffel", mime: "text/x-eiffel"},
		"elm": {mode:"elm", mime: "text/x-elm"},
		"erlang": {mode:"erlang", mime: "text/x-erlang"},
		"factor": {mode:"factor", mime: "text/x-factor"},
		"fcl": {mode:"fcl", mime: "text/x-fcl"},
		"forth": {mode:"forth", mime: "text/x-forth"},
		"fortran": {mode:"fortran", mime: "text/x-fortran"},
		"gfm": {mode:"gfm", mime: "text/x-gfm"},
		"feature": {mode:"gherkin", mime: "text/x-feature"},
		"go": {mode:"go", mime: "text/x-go"},
		"groovy": {mode:"groovy", mime: "text/x-groovy"},
		"haml": {mode:"haml", mime: "text/x-haml"},
		"handlebars-template": {mode:"handlebars", mime: "text/x-handlebars-template"},
		"haskell": {mode:"haskell", mime: "text/x-haskell"},
		"literate-haskell": {mode:"haskell-literate", mime: "text/x-literate-haskell"},
		"haxe": {mode:"haxe", mime: "text/x-haxe"},
		"hxml": {mode:"haxe", mime: "text/x-hxml"},
		"aspx": {mode:"htmlembedded", mime: "application/x-aspx"},
		"ejs": {mode:"htmlembedded", mime: "application/x-ejs"},
		"erb": {mode:"htmlembedded", mime: "application/x-erb"},
		"jsp": {mode:"htmlembedded", mime: "application/x-jsp"},
		"html": {mode:"htmlmixed", mime: "text/html"},
		"http": {mode:"http", mime: "message/http"},
		"idl": {mode:"idl", mime: "text/x-idl"},
		"jade": {mode:"jade", mime: "text/x-jade"},
		"ecmascript": {mode:"javascript", mime: "application/ecmascript"},
		"javascript": {mode:"javascript", mime: "application/javascript"},
		"json": {mode:"javascript", mime: "application/json"},
		"ld": {mode:"javascript", mime: "application/ld"},
		"typescript": {mode:"javascript", mime: "application/typescript"},
		"javascript": {mode:"javascript", mime: "application/x-javascript"},
		"json": {mode:"javascript", mime: "application/x-json"},
		"ecmascript": {mode:"javascript", mime: "text/ecmascript"},
		"javascript": {mode:"javascript", mime: "text/javascript"},
		"typescript": {mode:"javascript", mime: "text/typescript"},
		"jsx": {mode:"jsx", mime: "text/jsx"},
		"julia": {mode:"julia", mime: "text/x-julia"},
		"livescript": {mode:"livescript", mime: "text/x-livescript"},
		"lua": {mode:"lua", mime: "text/x-lua"},
		"markdown": {mode:"markdown", mime: "text/x-markdown"},
		"mathematica": {mode:"mathematica", mime: "text/x-mathematica"},
		"mbox": {mode:"mbox", mime: "application/mbox"},
		"mirc": {mode:"mirc", mime: "text/mirc"},
		"modelica": {mode:"modelica", mime: "text/x-modelica"},
		"fsharp": {mode:"mllike", mime: "text/x-fsharp"},
		"ocaml": {mode:"mllike", mime: "text/x-ocaml"},
		"mscgen": {mode:"mscgen", mime: "text/x-mscgen"},
		"msgenny": {mode:"mscgen", mime: "text/x-msgenny"},
		"xu": {mode:"mscgen", mime: "text/x-xu"},
		"mumps": {mode:"mumps", mime: "text/x-mumps"},
		"nginconf": {mode:"nginx", mime: "text/x-nginx-conf"},
		"nsis": {mode:"nsis", mime: "text/x-nsis"},
		"n-triples": {mode:"ntriples", mime: "text/n-triples"},
		"octave": {mode:"octave", mime: "text/x-octave"},
		"oz": {mode:"oz", mime: "text/x-oz"},
		"pascal": {mode:"pascal", mime: "text/x-pascal"},
		"perl": {mode:"perl", mime: "text/x-perl"},
		"httpd-php": {mode:"php", mime: "application/x-httpd-php"},
		"httpd-php-open": {mode:"php", mime: "application/x-httpd-php-open"},
		"php": {mode:"php", mime: "text/x-php"},
		"pig": {mode:"pig", mime: "text/x-pig"},
		"powershell": {mode:"powershell", mime: "application/x-powershell"},
		"ini": {mode:"properties", mime: "text/x-ini"},
		"properties": {mode:"properties", mime: "text/x-properties"},
		"protobuf": {mode:"protobuf", mime: "text/x-protobuf"},
		"puppet": {mode:"puppet", mime: "text/x-puppet"},
		"cython": {mode:"python", mime: "text/x-cython"},
		"python": {mode:"python", mime: "text/x-python"},
		"q": {mode:"q", mime: "text/x-q"},
		"rsrc": {mode:"r", mime: "text/x-rsrc"},
		"rpm-changes": {mode:"rpm", mime: "text/x-rpm-changes"},
		"rpm-spec": {mode:"rpm", mime: "text/x-rpm-spec"},
		"rst": {mode:"rst", mime: "text/x-rst"},
		"ruby": {mode:"ruby", mime: "text/x-ruby"},
		"rustsrc": {mode:"rust", mime: "text/x-rustsrc"},
		"sas": {mode:"sas", mime: "text/x-sas"},
		"sass": {mode:"sass", mime: "text/x-sass"},
		"scheme": {mode:"scheme", mime: "text/x-scheme"},
		"bash": {mode:"shell", mime: "text/x-sh"},
		"sieve": {mode:"sieve", mime: "application/sieve"},
		"slim": {mode:"slim", mime: "application/x-slim"},
		"slim": {mode:"slim", mime: "text/x-slim"},
		"stsrc": {mode:"smalltalk", mime: "text/x-stsrc"},
		"smarty": {mode:"smarty", mime: "text/x-smarty"},
		"solr": {mode:"solr", mime: "text/x-solr"},
		"soy": {mode:"soy", mime: "text/x-soy"},
		"sparql-query": {mode:"sparql", mime: "application/sparql-query"},
		"spreadsheet": {mode:"spreadsheet", mime: "text/x-spreadsheet"},
		"cassandra": {mode:"sql", mime: "text/x-cassandra"},
		"gql": {mode:"sql", mime: "text/x-gql"},
		"hive": {mode:"sql", mime: "text/x-hive"},
		"mariadb": {mode:"sql", mime: "text/x-mariadb"},
		"mssql": {mode:"sql", mime: "text/x-mssql"},
		"mysql": {mode:"sql", mime: "text/x-mysql"},
		"pgsql": {mode:"sql", mime: "text/x-pgsql"},
		"plsql": {mode:"sql", mime: "text/x-plsql"},
		"sql": {mode:"sql", mime: "text/x-sql"},
		"latex": {mode:"stex", mime: "text/x-latex"},
		"stex": {mode:"stex", mime: "text/x-stex"},
		"styl": {mode:"stylus", mime: "text/x-styl"},
		"swift": {mode:"swift", mime: "text/x-swift"},
		"tcl": {mode:"tcl", mime: "text/x-tcl"},
		"textile": {mode:"textile", mime: "text/x-textile"},
		"tiddlywiki": {mode:"tiddlywiki", mime: "text/x-tiddlywiki"},
		"tiki": {mode:"tiki", mime: "text/tiki"},
		"toml": {mode:"toml", mime: "text/x-toml"},
		"tornado": {mode:"tornado", mime: "text/x-tornado"},
		"troff": {mode:"troff", mime: "application/x-troff"},
		"troff": {mode:"troff", mime: "text/troff"},
		"troff": {mode:"troff", mime: "text/x-troff"},
		"ttcn-cfg": {mode:"ttcn-cfg", mime: "text/x-ttcn-cfg"},
		"turtle": {mode:"turtle", mime: "text/turtle"},
		"twig": {mode:"twig", mime: "text/x-twig"},
		"vb": {mode:"vb", mime: "text/x-vb"},
		"vbscript": {mode:"vbscript", mime: "text/vbscript"},
		"velocity": {mode:"velocity", mime: "text/velocity"},
		"systemverilog": {mode:"verilog", mime: "text/x-systemverilog"},
		"tlv": {mode:"verilog", mime: "text/x-tlv"},
		"verilog": {mode:"verilog", mime: "text/x-verilog"},
		"vhdl": {mode:"vhdl", mime: "text/x-vhdl"},
		"vue": {mode:"vue", mime: "script/x-vue"},
		"webidl": {mode:"webidl", mime: "text/x-webidl"},
		"xml": {mode:"xml", mime: "application/xml"},
		"html": {mode:"xml", mime: "text/html"},
		"xml": {mode:"xml", mime: "text/xml"},
		"xquery": {mode:"xquery", mime: "application/xquery"},
		"yacas": {mode:"yacas", mime: "text/x-yacas"},
		"yaml": {mode:"yaml", mime: "text/x-yaml"},
		"ez80": {mode:"z80", mime: "text/x-ez80"},
		"z80": {mode:"z80", mime: "text/x-z80"}
    };

    function get_mode_mime(lang)
    {
	var mm = modemime[lang]
	return (mm == null ? {mode:"text", mime: "text/x-text"} : mm);
    }

    // возвращает перечень языков для автодополнения
    window.get_langs = function ()
    {
	return Object.keys(modemime);
    }

    var isBlock = /^(p|li|div|h\\d|pre|blockquote|td)$/;

    function textContent(node, out) {
	if (node.nodeType == 3) return out.push(node.nodeValue);
	for (var ch = node.firstChild; ch; ch = ch.nextSibling) {
	    textContent(ch, out);
	    if (isBlock.test(node.nodeType)) out.push("\n");
	}
    }

    CodeMirror.colorize = function(collection, defaultMode) {
	if (!collection) collection = document.body.getElementsByTagName("pre");

	for (var i = 0; i < collection.length; ++i) {
	    var node = collection[i];

	    var re = /data-lang-([a-z0-9\-]*)/;
	    var match = re.exec(node.className);
	    var mode = defaultMode;
	    if (match != null) mode = match[1];
	    if (!mode) continue;

	    var modemime = get_mode_mime(mode);	    
//	    alert('mode:' + modemime.mode + ', mime:' + modemime.mime);
	    if (modemime.mode != 'text') require_js('/plugin_assets/milofon_prelum/javascripts/codemirror/mode/' +modemime.mode + '/' + modemime.mode + '.js');
	    
	    
	    var text = [];
	    textContent(node, text);
	    node.innerHTML = "";
	    CodeMirror.runMode(text.join(""), modemime.mime, node);

	    node.className += " cm-s-prelum-cm";
	}
    };
});
