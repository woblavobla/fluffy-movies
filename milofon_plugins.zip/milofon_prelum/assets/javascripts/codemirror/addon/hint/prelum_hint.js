// Copyright (c) 2015, Alexey Koptev, Oleg Lelenkov. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice,
//    this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
// 3. Neither the name of the copyright holder nor the names of its contributors
//    may be used to endorse or promote products derived from this software
//    without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
// COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
// INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL DAMAGES (INCLUDING,
// BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
// AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
// OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
// OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.



function get_cur_word(curLine, word, start, end)
{
    while (start && word.test(curLine.charAt(start - 1))) --start;
    var curWord = start != end && curLine.slice(start, end);

    return {curWord: curWord, start: start};
}

(function(mod) {
    if (typeof exports == "object" && typeof module == "object") // CommonJS
	mod(require("../../lib/codemirror"));
    else if (typeof define == "function" && define.amd) // AMD
	define(["../../lib/codemirror"], mod);
    else // Plain browser env
	mod(CodeMirror);
})(function(CodeMirror) {
    "use strict";

    CodeMirror.registerHelper("hint", "anyword", function(editor, options) {
	var word = null;
	var cur = editor.getCursor();
	var curLine = editor.getLine(cur.line);
	var end = cur.ch;
	var start = end;
	var type = null
	var curWord = null;
	var data = null;
	
	// ЛИСТИНГ
	type = /^листинг\([\s]*[a-z0-9\-]*/;
	if (type.test(curLine.slice(0,cur.ch)))
	{
	    word = /[a-z0-9\-]+/;
	    data = get_cur_word(curLine, word, start, end);
	    curWord = data.curWord;
	    start = data.start;
	    
	    return {
		// используется перечень языков window.langs
		list: (!curWord ? window.langs : window.langs.filter(function(item) {
		    return item.match(new RegExp('^' + curWord));
		})).sort(),
		from: CodeMirror.Pos(cur.line, start),
		to: CodeMirror.Pos(cur.line, end)
	    };	    
	}

	// ССЫЛКИ
	type = /^.+==[\s]*[\-а-яa-z0-9]*/;
	if (type.test(curLine.slice(0,cur.ch)))
	{
	    word = /[\-а-яa-z0-9]+/;
	    data = get_cur_word(curLine, word, start, end);
	    curWord = data.curWord;
	    start = data.start;
	    // ссылки полученные из документа (window.refs) за исключением редактируемой секции объединяются с ссылками в тексте редактируемой секции, которые получаются средствами регулярного выражения (window.refs_re) зависящего от текущей спецификации
	    
	    
	    var all_refs = window.refs.concat(editor.getValue().scan(window.refs_re)).filter(function (value, index, self) { return self.indexOf(value) === index;}).sort();
	    return {
		list: (!curWord ? all_refs : all_refs.filter(function(item) {
		    return item.match(new RegExp('^' + curWord));
		})).sort(),
		from: CodeMirror.Pos(cur.line, start),
		to: CodeMirror.Pos(cur.line, end)
	    };	    
	}

	// КЛЮЧЕВЫЕ СЛОВА
	type = /^.*/;
	if (type.test(curLine.slice(0,cur.ch)) || cur.ch == 0)
	{
	    // регулярное выражение, определяющее допустимые симовлы ключевых слов
	    word = window.autocomplete_symbols;
	    data = get_cur_word(curLine, word, start, end);
	    curWord = data.curWord;
	    start = data.start;

	    return {
		list: (!curWord ? window.keywords : window.keywords.filter(function(item) {
		    return item.match(new RegExp('^' + curWord));
		})).sort(),
		from: CodeMirror.Pos(cur.line, start),
		to: CodeMirror.Pos(cur.line, end)
	    };
	}
    });
});
