# coding: utf-8


# Copyright (c) 2015-2016, Alexey Koptev, Oleg Lelenkov. All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
# COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.

require_relative 'translator-client/translator-client'

module Org
  module Milofon
    module Prelum
      module Translator
        
        # TODO: (#786) получать массив регулярных выражений из транслятора
        RE = {'get-specification' => '^документ\(([\.а-яА-Яa-zA-Z0-9-]+)',
              'is-prelum' => '^документ\([\.а-яА-Яa-zA-Z0-9-]+(?:\s*,\s*[\.а-яА-Яa-zA-Z0-9-]+)*\)',
              'parameters' => '\([\.а-яА-Яa-zA-Z0-9-]+(?:\s*,\s*[\.а-яА-Яa-zA-Z0-9-]+)*\)', 'blocks' => '^==#([0-9]+)(?:,\s*[a-zа-я0-9-]+)?=='}        
        
        # HOST =  Setting.plugin_milofon_prelum['translator-host']

        # PORT = Setting.plugin_milofon_prelum['translator-port']

        # MATHJAX_URL = Setting.plugin_milofon_prelum['mathjax-url']

        # DEFAULT_SPEC = Setting.plugin_milofon_prelum['default-spec']
        
        # # TODO: (#) получать таблицу соответствия карточки и спецификации из настроек
        # trackers:
        #  15: ГОСТ-19-106-78
        # TRACKERS = {}

        # FIELD_SPEC = Setting.plugin_milofon_prelum['field-spec']
        
        # вывод в формат TEXTILE
        def self.to_textile(text, project, page)
          client = Org::Milofon::Prelum::Translator::Client.new(
              Setting.plugin_milofon_prelum['translator-host'],
              Setting.plugin_milofon_prelum['translator-port'],
              Setting.plugin_milofon_prelum['use-ssl-protocol'],
              Org::Milofon::Prelum::Translator::Format::TEXTILE)
          response = client.request(assemble_doc(text, []), {'проект' => project.to_s, 'документ' => page.to_s})
          response.data.force_encoding('UTF-8')
        end

        # вывод в формат PDF
        def self.to_pdf(text, project, page)
          client = Org::Milofon::Prelum::Translator::Client.new(
              Setting.plugin_milofon_prelum['translator-host'],
              Setting.plugin_milofon_prelum['translator-port'],
              Setting.plugin_milofon_prelum['use-ssl-protocol'],
              Org::Milofon::Prelum::Translator::Format::PDF)
          response = client.request(assemble_doc(text, []), {'проект' => project.to_s, 'документ' => page.to_s})
          response.data
        end

        # определение спецификации по тексту
        def self.get_spec(text)
          text.match(Regexp.new(Org::Milofon::Prelum::Translator::RE['get-specification']))
          return $1
        end

        # получение перечня рубрик
        def self.get_heading(spec)

          # TODO: (#788) получать перечень рубрик из транслятора
          return {'+' => '1', '++' => '2', '=+' => '3', '==+' => '4', 'приложение' => '1', 'перечень-терминов' => '1', 'перечень-сокращений' => '1', 'перечень-рисунков' => '1', 'перечень-таблиц' => '1', 'предметный-указатель' => '1', 'перечень-ссылочных-документов' => '1', 'перечень-символов' => '1', 'введение' => '1', 'заключение' => '1', 'список-использованных-источников' => '1'}
        end
        
        # получение правил подсветки спецификации для wiki-страницы
        def self.get_mode(text)

          spec = Org::Milofon::Prelum::Translator.get_spec(text)
          mode = ''

          if spec != nil and text != '' and File.file?("#{Rails.root}/plugins/milofon_prelum/lib/modes/#{spec}.js") then 
            # TODO: (#787) получать правила подсветки синтаксиса спецификаций из транслятора
            mode = File.read("#{Rails.root}/plugins/milofon_prelum/lib/modes/#{spec}.js")
          else
            # TODO:  (#787) получать правила подствеки синтаксиса для спецификации по-умолчанию из транслятора
            mode = File.read("#{Rails.root}/plugins/milofon_prelum/lib/modes/#{Setting.plugin_milofon_prelum['default-spec']}.js")
          end
          
          return mode
        end

        # получение правил подсветки спецификации для карточки
        def self.get_mode_for_issue(tracker_id, spec)
          return File.read("#{Rails.root}/plugins/milofon_prelum/lib/modes/#{spec}.js") if spec != nil
          return File.read("#{Rails.root}/plugins/milofon_prelum/lib/modes/#{Org::Milofon::Prelum::Translator.get_mode_for_tracker(tracker_id)}.js") if spec == nil and Org::Milofon::Prelum::Translator.get_mode_for_tracker(tracker_id) != nil
          return nil
        end
        
        def self.get_mode_for_tracker(tracker_id)
          mode = nil
          Setting.plugin_milofon_prelum['trackers'].scan(/(\d+)=(\S+)/) { |id, spec| mode = spec if id == tracker_id.to_s } if Setting.plugin_milofon_prelum['trackers'] != nil
          return mode 
        end

        # получения текста для новых документов
        def self.get_new_text()
          
          # TODO: (#789) обращаться к транслятору для получения шаблона по-умолчанию по обозначению спецификации из настроек модуля
          
          "документ(#{Setting.plugin_milofon_prelum['default-spec']})

--

титульный-лист()
лу - ru.xxxx.00000-00 00 00-ЛУ
поле-3-п - Программное средство
поле-3-д - Руководство системного программиста
поле-4 - ru.xxxx.00000-00 00 00
--

аннотация()

Настоящий документ содержит ...

содержание()


+ Общие сведения о программе

"
        end

        def self.templates()
          local = {}
          Dir.glob("#{Rails.root}/plugins/milofon_prelum/lib/templates/*") do |file|
            local['L_' + File.basename(file)] = File.basename(file).gsub('__', '.').gsub('_', ' ')
          end
          
          # TODO: (#789) добавить получение списка шаблонов от транслятора
          remote = {}
          return local.merge(remote)
        end

        TEMPLATES = Org::Milofon::Prelum::Translator.templates

        def self.get_template(key)
          if key.start_with?('L_') then
            return File.read("#{Rails.root}/plugins/milofon_prelum/lib/templates/" + key.gsub(/^L_/, ''))
          else
            # TODO: (#789) добавить получение текста шаблона от транслятора
            return Org::Milofon::Prelum::Translator.get_new_text()
          end
        end

        def self.get_memo(spec)
          # TODO: (#791) получать справку от транслятора
          
          memo = <<MEMO
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<title>Форматирование Wiki</title>
<style type="text/css">
h1 { font-family: Verdana, sans-serif; font-size: 14px; text-align: center; color: #444; }
body { font-family: Verdana, sans-serif; font-size: 12px; color: #444; }
table th { padding-top: 1em; }
table td { vertical-align: top; background-color: #f5f5f5; height: 2em; vertical-align: middle;}
table td code { font-size: 1.2em; }
table td h1 { font-size: 1.8em; text-align: left; }
table td h2 { font-size: 1.4em; text-align: left; }
table td h3 { font-size: 1.2em; text-align: left; }

table.sample { border-collapse: collapse; border-spacing: 0; margin: 4px; }
table.sample th, table.sample td { border: solid 1px #bbb; padding: 4px; height: 1em; }
</style>
</head>
<body>

<h1>Синтаксис спецификации #{spec}</h1>

<table style="width:100%">

    <tr>
        <td style="width:50%;"><code>документ</code></td>
        <td style="width:50%;">документ</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>лист-утверждения</code></td>
        <td style="width:50%;">лист утвеждения</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>титульный-лист</code></td>
        <td style="width:50%;">титульный лист</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>аннотация</code></td>
        <td style="width:50%;">аннотация</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>содержание</code></td>
        <td style="width:50%;">содержание</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>+</code></td>
        <td style="width:50%;">раздел</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>++</code></td>
        <td style="width:50%;">подраздел</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>=</code></td>
        <td style="width:50%;">пункт</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>=+</code></td>
        <td style="width:50%;">пункт с заголовком</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>==</code></td>
        <td style="width:50%;">подпункт</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>==+</code></td>
        <td style="width:50%;">подпункт с заголовком</td>
    </tr>
    <tr>
        <td style="width:50%;"><code></code></td>
        <td style="width:50%;">абзац</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>-</code></td>
        <td style="width:50%;">перечисление</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>)</code></td>
        <td style="width:50%;">перечисление нумерованное</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>рисунок</code></td>
        <td style="width:50%;">рисунок</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>формула</code></td>
        <td style="width:50%;">формула</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>таблица</code></td>
        <td style="width:50%;">таблица</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>листинг</code></td>
        <td style="width:50%;">листинг</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>примечание</code></td>
        <td style="width:50%;">примечание</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>примечания</code></td>
        <td style="width:50%;">примечания</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>сноска</code></td>
        <td style="width:50%;">сноска</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>приложение</code></td>
        <td style="width:50%;">приложение</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>перечень-терминов</code></td>
        <td style="width:50%;">перечень терминов</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>перечень-сокращений</code></td>
        <td style="width:50%;">перечень сокращений</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>перечень-рисунков</code></td>
        <td style="width:50%;">перечень рисунков</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>перечень-таблиц</code></td>
        <td style="width:50%;">перечень таблиц</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>предметный-указатель</code></td>
        <td style="width:50%;">предметный указатель</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>перечень-ссылочных-документов</code></td>
        <td style="width:50%;">предметный ссылочных документов</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>перечень-символов</code></td>
        <td style="width:50%;">перечень символов и числовых коэффициентов</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>лист-регистрации-изменений</code></td>
        <td style="width:50%;">лист регистрации изменений</td>
    </tr>
    <tr>
        <td style="width:50%;"><code>часть</code></td>
        <td style="width:50%;">часть</td>
    </tr>


</table>

<p><a href="wiki_syntax_detailed.html" onclick="window.open('wiki_syntax_detailed.html', '', ''); return false;">Больше информации</a></p>

</body>
</html>
MEMO
          return memo
        end

        def self.get_keywords(spec)
          # TODO: получать список ключевых слов из транслятора по обозначению спецификации
          list = "[')','+','++','-','=','=+','==','==+','лист-утверждения','лист-регистрации-изменений','часть','сноска','листинг','рисунок','таблица','формула','документ','перечень-таблиц','перечень-рисунков','перечень-символов','перечень-терминов','перечень-ссылочных-документов','перечень-сокращений','аннотация','титульный-лист','приложение','примечание','примечания','содержание','предметный-указатель']"
          return list
        end

        def self.get_autocomplete_symbols(spec)
          # TODO: получать список символов из транслятора (по спецификации формировать только символы символьных предложений, остальное стандартно)
          return '/[\)\+\-=а-яa-z0-9]+/'
        end

        # Функция возвращает список ссылок из документа за исключением редактируемой секции.
        # Применяется только для wiki страниц, т.к. при редактировании иных объектов секционирование не поддерживается
        def self.get_refs(text, index)
          sections = Redmine::WikiFormatting.formatter.new(text).extract_sections(index.to_i)
          doc = sections[0] + sections[2]

          # TODO: получать регулярное выражение для ключевых слов со ссылкой (подключена функция ссылка) из транслятора
          refs = doc.scan /^(?:\)|==\+|==|\+\+|приложение|=\+|=|\+|рисунок|таблица|формула)\(([\.а-яА-Яa-zA-Z0-9-]+)/
          return "['#{refs.join("','")}']"
        end

        def self.get_refs_re(spec)
          return '/^(?:\)|==\+|==|\+\+|приложение|=\+|=|\+|рисунок|таблица|формула)\(([\.а-яА-Яa-zA-Z0-9-]+)/gm'
        end

        def self.check_document(field_id, obj_id, section, index)
          # TODO: необходимо проработать вопрос проверки составных документов (assemble_doc)
          doc = ''
          found = []

          # это пока для тестирования
          found.push({:from => {:line => 0, :ch => 0}, :to => {:line => 0, :ch => 10}, :message => "test1 " + obj_id, :severity => 'warning'})
          found.push({:from => {:line => 4, :ch => 0}, :to => {:line => 4, :ch => 10}, :message => "test2 " + section, :severity => 'error'})
          found.push({:from => {:line => 5, :ch => 0}, :to => {:line => 5, :ch => 10}, :message => "test3 " + index, :severity => 'warning'})

          
          if field_id == 'content_text' then
            text = WikiPage.find_by_id(obj_id).content.text

            if index == '' then
              doc = section
            else
              sections = Redmine::WikiFormatting.formatter.new(text).extract_sections(index.to_i)
              doc = sections[0] + section + sections[2]
            end

          end

          if field_id == 'issue_description' then
            doc = section
          end

          # TODO: здесь заменить заглушку на вызов транслятора с передачей doc и получением found
          
          # ------------------------------------------------------------------
          # здесь пока в порядке прототипа функции проверки на стороне клиента
          # функция проверки ссылок на блоки
          
          line_number = 0
          section.lines.each do |line|
            if line.match(Regexp.new(Org::Milofon::Prelum::Translator::RE['blocks'])) then
              found.push({:from => {:line => line_number, :ch => 0}, :to => {:line => line_number, :ch => line.index('==', 3) + 2}, :message => "Блок текста ##{$1} не найден", :severity => 'error'}) if not Issue.find_by_id($1)
            end
            
            line_number = line_number + 1
          end
                    
          return found
        end

        def self.assemble_doc(text, ids)
          text.gsub(Regexp.new(Org::Milofon::Prelum::Translator::RE['blocks'])) do |m|
            if not ids.include? $1 then
              ids.push $1
              assemble_doc(Issue.find_by_id($1).description, ids)
            else
              "!!! РЕКУРСИЯ В БЛОКЕ ##{$1}.  СВЯЗЬ #{ids.to_s}. ТЕКУЩИЙ БЛОК ##{ids.pop} !!!"
            end
          end
        end
      end
    end
  end
end
