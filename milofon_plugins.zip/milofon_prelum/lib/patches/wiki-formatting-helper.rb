# coding: utf-8

# Copyright (c) 2015-2016, Alexey Koptev, Oleg Lelenkov. All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
# COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.

Redmine::WikiFormatting::Textile::Helper.class_eval do
  # Функция wikitoolbar_for (lib/redmine/wiki_formatting/textile/helper.rb) переопределена, добавлены не обязательные параметры, которые нужны для функционирования модуля расширения.
  # В переменной field_id передается html-идентификатор редактируемого объекта, он же используется как тип редактируемого текста.
  # Значение устанавливается в вызовах функции wikitoolbar_for в view соответствующих объектов, например, app/view/issues/_form.html.erb

  def wikitoolbar_for(field_id, text = nil, index = nil, obj_id = nil, issue_spec = nil)

    heads_for_wiki_formatter
    
    if (field_id != 'content_text' and field_id != 'issue_description') or ((field_id == 'issue_description' or field_id == 'content_text') and text == nil and index == nil and obj_id == nil and issue_spec == nil) then
      # если редактируется не wiki и не содержание issue, то сохранятеся изначальный алгоритм данной функции

      # Is there a simple way to link to a public resource?
      url = "#{Redmine::Utils.relative_url_root}/help/#{current_language.to_s.downcase}/wiki_syntax.html"
      javascript_tag("var wikiToolbar = new jsToolBar(document.getElementById('#{field_id}')); wikiToolbar.setHelpLink('#{escape_javascript url}'); wikiToolbar.draw();")

    else

      spec = nil
      refs = nil
      
      if field_id == 'content_text' then
        # в переменной text содержится весь текст документа
        spec = Org::Milofon::Prelum::Translator.get_spec(text)
        refs = Org::Milofon::Prelum::Translator.get_refs(text, index)
      elsif field_id == 'issue_description' then
        spec = issue_spec
        refs = '[]'
      end

      help_link = escape_javascript "#{Redmine::Utils.relative_url_root}/memo/#{spec}"
      keywords = Org::Milofon::Prelum::Translator.get_keywords(spec)
      autocomplete_symbols = Org::Milofon::Prelum::Translator.get_autocomplete_symbols(spec)
      refs_re = Org::Milofon::Prelum::Translator.get_refs_re(spec)
      
      # window.obj_id - идентификатор редактируемой страницы или карточки
      # window.index - номер редактируемой секции wiki-страницы
      # window.field_id - html-идентификатор редактируемого объекта
      # window.help_link - адрес страницы справки для данной спецификации
      # window.worker_url - адрес для загрузки механизма асинхронного запуска проверки арфографии
      # window.keywords - список ключевых слов для данной спецификации, который применяется в механизме автодополнения
      # window.autocomplete_symbols - регулярное выражение, определяющее допустимые симовлы ключевых слов, которое используется в механизме автодополнения (prelum_hint.js)
      # window.langs - перечень языков для автодополнения
      # window.refs - ссылки документа, за исключением тех, которые находятся в редактируемой секции
      # window.refs_re - регулярное выражение для получения ссылок из текста редактируемой секции (зависит от пецификации документа)
      js = <<JS
window.obj_id = '#{obj_id}';
window.index = '#{index}';
window.field_id = '#{field_id}';
window.spec='#{spec}';
window.help_link = '#{help_link}';
window.worker_url = '#{Redmine::Utils.relative_url_root}/plugin_assets/milofon_prelum/javascripts/spell_worker.js';
window.keywords = #{keywords};
window.autocomplete_symbols = #{autocomplete_symbols};
window.langs = get_langs();
window.refs = #{refs};
window.refs_re = #{refs_re};
require_js('/plugin_assets/milofon_prelum/javascripts/editor.js');
JS
      javascript_tag(js)
    end
    
  end

  # Переопределена функция initial_page_content, которая формирует начальное содержание (содерание по-умолчанию) для вновь созданной страницы wiki
  def initial_page_content(page)
    if page.project.module_enabled?(:milofon_prelum)
      Org::Milofon::Prelum::Translator.get_new_text
    else
      "h1. #{@page.pretty_title}"
    end
  end

  # Переопределена функция heads_for_wiki_formatter, которая обеспечивает подключение необходимых для функционирования модуля расширения библиотек JavaScript и CSS на стороне веб-браузера
  def heads_for_wiki_formatter
    unless @heads_for_wiki_formatter_included
      content_for :header_tags do
        # панель редактора (именно в таком порядке, т.к. cm перекрывет настройку элементов типа comdo)
        javascript_include_tag('jstoolbar/jstoolbar-textile.min') + "\n" +
          javascript_include_tag('jstoolbar/jstoolbar_codemirror.js', :plugin => 'milofon_prelum') + "\n" +
          # набор элементов панели редактора
          javascript_include_tag('jstoolbar/jstoolbar_prelum.js', :plugin => 'milofon_prelum') + "\n" +
          # наименование элементов панели редактора
          javascript_include_tag("jstoolbar/lang/jstoolbar-#{current_language.to_s.downcase}", :plugin => 'milofon_prelum') + "\n" +
          # механизм полноэкранного редактирования
          javascript_include_tag('codemirror/addon/display/fullscreen.js', :plugin => 'milofon_prelum') + "\n" +
          # механизм декларативного описания правил подсветки синтаксиса
          javascript_include_tag('codemirror/addon/mode/simple.js', :plugin => 'milofon_prelum') + "\n" +
          # механизм вывода сообщений в строках редактора
          javascript_include_tag('codemirror/addon/lint/lint.js', :plugin => 'milofon_prelum') + "\n" +
          # функция формирования сообщений в строках редактора 
          javascript_include_tag('codemirror/addon/lint/prelum_lint.js', :plugin => 'milofon_prelum') + "\n" +
          # механизм автодополнения
          javascript_include_tag('codemirror/addon/hint/show-hint.js', :plugin => 'milofon_prelum') + "\n" +
          # функция формирования списков автодополениня
          javascript_include_tag('codemirror/addon/hint/prelum_hint.js', :plugin => 'milofon_prelum') + "\n" +
          # механизм подсветки текущей строки в редакторе
          javascript_include_tag('codemirror/addon/selection/active-line.js', :plugin => 'milofon_prelum') + "\n" +
          # механизм свертывания текста
          javascript_include_tag('codemirror/addon/fold/foldcode.js', :plugin => 'milofon_prelum') + "\n" +
          javascript_include_tag('codemirror/addon/fold/foldgutter.js', :plugin => 'milofon_prelum') + "\n" +
          # правила свертывания текста
          javascript_include_tag('codemirror/addon/fold/prelum_fold.js', :plugin => 'milofon_prelum') + "\n" +
          # механизм поиска текста в редакторе
          javascript_include_tag('codemirror/addon/search/search.js', :plugin => 'milofon_prelum') + "\n" +
          javascript_include_tag('codemirror/addon/search/searchcursor.js', :plugin => 'milofon_prelum') + "\n" +
          javascript_include_tag('codemirror/addon/dialog/dialog.js', :plugin => 'milofon_prelum') + "\n" +
          # адаптированная версия Combobox
          javascript_include_tag('jquery/combobox.js', :plugin => 'milofon_prelum') + "\n" +
          # механизм проверки орфографии текста
          javascript_include_tag('typojs/typo2.js', :plugin => 'milofon_prelum') + "\n" +
          # механизм асинхронной загрузки словарей
          javascript_include_tag('spell.js', :plugin => 'milofon_prelum') + "\n" +                   

          # основные стили редактора
          stylesheet_link_tag('codemirror.css', :plugin => 'milofon_prelum') + "\n" +
          # стили механизма автодополнения
          stylesheet_link_tag('show-hint.css', :plugin => 'milofon_prelum') + "\n" +
          # стили механизма вывода сообщений в строках редактора
          stylesheet_link_tag('lint.css', :plugin => 'milofon_prelum') + "\n" +
          # стили элементов диалога в редакторе
          stylesheet_link_tag('dialog.css', :plugin => 'milofon_prelum') + "\n" +    
          # стили механизма полноэранного редактирования
          stylesheet_link_tag('fullscreen.css', :plugin => 'milofon_prelum') + "\n" +
          # стили механизма свертывания текста
          stylesheet_link_tag('foldgutter.css', :plugin => 'milofon_prelum') + "\n" +
          # стили панели редактора
          stylesheet_link_tag('jstoolbar')
      end
      @heads_for_wiki_formatter_included = true
    end
  end
end
