# coding: utf-8
Redmine::WikiFormatting::Textile::Formatter.class_eval do
  def extract_sections(index)

    @pre_list = []
    text = self.dup
    rip_offtags text, false, false
    before = ''
    s = ''
    after = ''
    i = 0
    l = 1
    started = false
    ended = false
# --------------------------------------------------------------------
    words = nil
    pattern = nil
    match = nil
    is_prelum = false
    spec = nil

    is_prelum = true if text =~ Regexp.new(Org::Milofon::Prelum::Translator::RE['is-prelum'])
    spec = Org::Milofon::Prelum::Translator.get_spec(text)
    
    if is_prelum == true then
      
      words = Org::Milofon::Prelum::Translator.get_heading(spec)

      match = words.keys.map{|w| Regexp.escape w }
      match = match.join('|')
      
      pattern = /(((?:.*?)(\A|\r?\n\s*\r?\n))((?:#{match})(?:#{Org::Milofon::Prelum::Translator::RE['parameters']})?[\s]?(.*?)$)|.*)/m

    else
      pattern = /(((?:.*?)(\A|\r?\n\s*\r?\n))(h(\d+)(#{RedCloth3::A}#{RedCloth3::C})\.(?::(\S+))?[ \t](.*?)$)|.*)/m
    end
# --------------------------------------------------------------------
    text.scan(pattern).each do |all, content, lf, heading, level|
      level = ''

      if heading.nil?
        if ended
          after << all
        elsif started
          s << all
        else
          before << all
        end
        break
      end
# --------------------------------------------------------------------
      if is_prelum == true then
        heading.match /^(#{match})(?:#{Org::Milofon::Prelum::Translator::RE['parameters']})?(?:\s|$)/
        level = words[$1]
      end
# --------------------------------------------------------------------
      i += 1

      if ended
        after << all
      elsif i == index
        l = level.to_i
        before << content
        s << heading
        started = true
      elsif i > index
        s << content
        if level.to_i > l
          s << heading
        else
          after << heading
          ended = true
        end
      else
        before << all
      end
    end

    sections = [before.strip, s.strip, after.strip]
    sections.each {|section| smooth_offtags_without_code_highlighting section}
    sections
  end
end
