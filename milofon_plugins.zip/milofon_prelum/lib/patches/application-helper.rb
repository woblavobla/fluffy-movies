# coding: utf-8
ApplicationHelper.class_eval do

  # устранение мрачной особенности не выводить ссылку на редактирвоания в первом разделе
  # заменил if @current_section > 1 на if @current_section >= 1
  def parse_sections(text, project, obj, attr, only_path, options)
    return unless options[:edit_section_links]
    text.gsub!(/(<h(\d)( [^>]+)?>(.+?)<\/h(\d)>)/i) do
      heading, level = $1, $2
      @current_section += 1
      if @current_section >= 1
        content_tag('div',
          link_to(l(:button_edit_section), options[:edit_section_links].merge(:section => @current_section),
                  :class => 'icon-only icon-edit'),
          :class => "contextual heading-#{level}",
          :title => l(:button_edit_section),
          :id => "section-#{@current_section}") + heading.html_safe
      else
        heading
      end
    end
  end

  # замена процедуры формирования ссылки ПРЕДПРОСМОТР
  # в код на JavaScript добавлено обновление элемента textarea актуальным текстом из CodeMirror
  def preview_link(url, form, target='preview', options={})
    if options["is_prelum"] then
    content_tag 'a', l(:label_preview), {
        :href => "#",
        :onclick => %|document.getElementById('old_' + window.field_id).value="документ(" + window.spec + ")\\n--\\n\\n" + window.prelumEditor.doc.getValue(); submitPreview("#{escape_javascript url_for(url)}", "#{escape_javascript form}", "#{escape_javascript target}"); return false;|,
        :accesskey => accesskey(:preview)
      }.merge(options)
    else
    content_tag 'a', l(:label_preview), {
        :href => "#",
        :onclick => %|submitPreview("#{escape_javascript url_for(url)}", "#{escape_javascript form}", "#{escape_javascript target}"); return false;|,
        :accesskey => accesskey(:preview)
      }.merge(options)
    end
  end

  # замена процедуры разбора ссылки на wiki с целью поддержки ссылок внутри карточеки
  def parse_wiki_links(text, project, obj, attr, only_path, options)
    text.gsub!(/(!)?(\[\[([^\]\n\|]+)(\|([^\]\n\|]+))?\]\])/) do |m|
      link_project = project
      esc, all, page, title = $1, $2, $3, $5

      # prelum
      prelum_anchor = (page.match(/^(.+?)\#(.+)$/) ? page.match(/^(.+?)\#(.+)$/)[2] : '')
      prelum_all = (all.start_with?('[[prelum-issues') ? "<a class=\"wiki-page\" href=\"##{prelum_anchor}\">#{title.html_safe}</a>" : all )
      # --

      if esc.nil?
        if page =~ /^([^\:]+)\:(.*)$/
          identifier, page = $1, $2
          link_project = Project.find_by_identifier(identifier) || Project.find_by_name(identifier)
          title ||= identifier if page.blank?
        end

        if link_project && link_project.wiki
          # extract anchor
          anchor = nil
          if page =~ /^(.+?)\#(.+)$/
            page, anchor = $1, $2
          end
          anchor = sanitize_anchor_name(anchor) if anchor.present?
          # check if page exists
          wiki_page = link_project.wiki.find_page(page)
          url = if anchor.present? && wiki_page.present? && (obj.is_a?(WikiContent) || obj.is_a?(WikiContent::Version)) && obj.page == wiki_page
            "##{anchor}"
          else
            case options[:wiki_links]
            when :local; "#{page.present? ? Wiki.titleize(page) : ''}.html" + (anchor.present? ? "##{anchor}" : '')
            when :anchor; "##{page.present? ? Wiki.titleize(page) : title}" + (anchor.present? ? "_#{anchor}" : '') # used for single-file wiki export
            else
              wiki_page_id = page.present? ? Wiki.titleize(page) : nil
              parent = wiki_page.nil? && obj.is_a?(WikiContent) && obj.page && project == link_project ? obj.page.title : nil
              url_for(:only_path => only_path, :controller => 'wiki', :action => 'show', :project_id => link_project,
               :id => wiki_page_id, :version => nil, :anchor => anchor, :parent => parent)
            end
          end
          link_to(title.present? ? title.html_safe : h(page), url, :class => ('wiki-page' + (wiki_page ? '' : ' new')))
        else
          # project or wiki doesn't exist
          # prelum
          prelum_all
          # --
        end
      else
        # prelum
        prelum_all
        # --
      end
    end
  end

  def sanitize_anchor_name(anchor)
    anchor.gsub(%r{[^\s\-\p{Word}\.]}, '').gsub(%r{\s+(\-+\s*)?}, '-')
  end
  
end
