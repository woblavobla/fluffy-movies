# coding: utf-8


# Copyright (c) 2015-2016, Alexey Koptev, Oleg Lelenkov. All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
# COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.

#
# точка расширения добавляет загрузку стилей модуля расширения
#

module Prelum
  module Hooks
    class ViewLayoutsBaseHtmlHeadHook < Redmine::Hook::ViewListener
      def view_layouts_base_html_head(context={})
        stylesheet_link_tag('prelum.css', :plugin => 'milofon_prelum') + "\n" +
          stylesheet_link_tag('prelum-19-106.css', :plugin => 'milofon_prelum') + "\n" +
          stylesheet_link_tag('prelum-7-32.css', :plugin => 'milofon_prelum') + "\n" +
          stylesheet_link_tag('github.css', :plugin => 'milofon_prelum') + "\n" +
          javascript_include_tag('include.js', :plugin => 'milofon_prelum') + "\n" +
          javascript_include_tag('hyphenator/Hyphenator_Loader.js', :plugin => 'milofon_prelum') + "\n" +
          javascript_include_tag('codemirror/lib/codemirror.js', :plugin => 'milofon_prelum') + "\n" +
          javascript_include_tag('codemirror/addon/runmode/runmode.js', :plugin => 'milofon_prelum') + "\n" +
          javascript_include_tag('codemirror/addon/runmode/colorize.js', :plugin => 'milofon_prelum') + "\n" +
          javascript_tag("Hyphenator_Loader.init({'ru':'информатизация','en':'hyphenationalgorithm'},'/plugin_assets/milofon_prelum/javascripts/hyphenator/Hyphenator.js',{useCSS3hyphenation:true});") + "\n" +
          javascript_tag("window.addEventListener('load',function(){CodeMirror.colorize();},false);") + "\n" +
          stylesheet_link_tag('prelum-cm.css', :plugin => 'milofon_prelum') + "\n" +               javascript_include_tag(Setting.plugin_milofon_prelum['mathjax-url']) + "\n"
      end
    end
  end
end
