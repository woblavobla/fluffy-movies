# -*- coding: utf-8 -*-


# Copyright (c) 2015, Alexey Koptev, Oleg Lelenkov. All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
# COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.

require 'msgpack'
require "net/https"

module Org
    module Milofon
        module Prelum
            module Translator
                class Client
                    def initialize(host, port, use_ssl, format)
                        @host, @port, @use_ssl = host, port, use_ssl
                        @format = format
                    end

                    def request(text, meta)
                        data = MessagePack.pack([@format, text, createMeta(meta)])

                        begin
                            resp = Net::HTTP.start(@host, @port, 
                                    :use_ssl => @use_ssl, 
                                    :verify_mode => OpenSSL::SSL::VERIFY_NONE) do |http|
                                req = Net::HTTP::Get.new("/translate")
                                req.body = data
                                req.content_type = "application/octet-stream"
                                http.request(req)
                            end
                        rescue
                            raise "Ошибка обращения к транслятору"
                        end

                        raise "Ошибка обращения к транслятору" if resp.code != '200'

                        return TranslateResponse.new(MessagePack.unpack(resp.body))
                    end

                    def createMeta(meta)
                        list = []
                        meta.each do |key, val|
                            list << [MetaType::TEXT, key, val]
                        end
                        list
                    end
                end

                class TranslateResponse
                    def initialize(data)
                        @errors = []
                        if not data[0].nil?
                            data[0].each do |msg, lvl, line, col|
                                @errors << {
                                    :message => msg,
                                    :level => lvl,
                                    :line => line,
                                    :column => col
                                }
                            end
                        end
                        @data = data[1]
                    end

                    def data()
                        return @data
                    end

                    def errors()
                        return @errors
                    end
                end

                module Format
                    TEXTILE = 0
                    LATEX = 1
                    PDF = 2
                    HTML = 3
                end

                module ErrorLevel
                    WARNING = 0
                    INFO = 1
                    FATAL = 2
                end

                module MetaType 
                    TEXT = 0    # текст
                    PICTURE = 1 # картинка
                    PART = 2    # часть
                end
            end
        end
    end
end
